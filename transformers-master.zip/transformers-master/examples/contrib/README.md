# Community contributed examples

This folder contains examples which are not actively maintained (mostly contributed by the community).

Using these examples together with a recent version of the library usually requires to make small (sometimes big) adaptations to get the scripts working.
